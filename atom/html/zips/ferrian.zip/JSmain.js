let APP = {
    op1: "",
    op2: "",
    opSw: false,
    segno: "",
    sign: 0,
    res: 1,
    output: "inserisci la funzione",

    addNum: function(e){
        if(!APP.opSw){
            APP.op1 = APP.op1*10 + parseInt($(e.target).val());
//            APP.output += APP.op1
        } else {
            APP.op2 = APP.op2*10 + parseInt($(e.target).val());
//            APP.output += APP.op2
        }
        $("#out").text(APP.op1 + "" + APP.segno + "" + APP.op2);
    },

    setSign: function (e){
        APP.sign = parseInt($(e.target).val());
        APP.segno = $(e.target).text();
        APP.opSw = true;
//        APP.output += APP.segno
        $("#out").text(APP.op1 + "" + APP.segno + "" + APP.op2);
    },

    printRes: function(){
        if(APP.opSw){
            switch(APP.sign){
                case 1:
                    APP.res = APP.op1 + APP.op2;
                break;
                case 2:
                    APP.res = APP.op1 - APP.op2;
                break;
                case 3:
                    APP.res = APP.op1 * APP.op2;
                break;
                case 4:
                    APP.res = APP.op1 / APP.op2;
                break;
            }
            APP.opSw = false;
        } else {
            $("#out").text("funzione incompleta");
        }
        APP.cancAll();
        $("#out").text(APP.res);
    },

    cancAll: function(){
        APP.op1 = "";
        APP.op2 = "";
        APP.opSw = false;
        APP.sign = 0;
        APP.segno = ""; 
//        APP.output = "";
        $("#out").text("inserisci la funzione");
    },

    start: function () {
        $(".num").on('click', APP.addNum);
        $(".segno").on('click', APP.setSign);
        $("#eq").on('click', APP.printRes);
        $("#canAll").on('click', APP.cancAll);
        $("#out").text(APP.output);
    }
}


$(document).ready(function () {
    APP.start();
}
);
